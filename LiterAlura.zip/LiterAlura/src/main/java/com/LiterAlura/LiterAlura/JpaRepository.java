package com.LiterAlura.LiterAlura;public interface JpaRepository<T, T1> {
}
