package com.LiterAlura.LiterAlura;

public @interface FeignClient {
    String name();

    String url();

    @FeignClient(name = "gutendex", url = "https://gutendex.com")
    public interface GutendexClient {
        @GetMapping("/books")
        List<Book> searchBooks(String query);
    }
}
