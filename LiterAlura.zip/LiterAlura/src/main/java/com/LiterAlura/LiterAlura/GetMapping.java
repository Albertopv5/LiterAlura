package com.LiterAlura.LiterAlura;

public @interface GetMapping {
}
