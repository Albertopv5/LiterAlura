package com.LiterAlura.LiterAlura;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.w3c.dom.ls.LSOutput;

import java.util.Scanner;

public class ConsolaApplicacion implements CommandLineRunner {
    private BookService bookService;
    @Autowired
    private Scanner scanner = new Scanner(System.in);

    @Override
    public void run(String... args) throws Exception {
        boolean running = true;

        while (running) {
            System.out.println("Catálogo de Libros");
            System.out.println("1. Buscar y guardar libros");
            System.out.println("2. Ver todos los libros");
            System.out.println("3. Ver libro por ID");
            System.out.println("4. Eliminar libro por ID");
            System.out.println("5. Eliminar todos los libros");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");

            int option = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (option) {
                case 1:
                    System.out.print("Ingrese el término de búsqueda: ");
                    String query = scanner.nextLine();
                    List<Book> books = bookService.searchAndSaveBooks(query);
                    System.out.println("Libros encontrados y guardados: " + books.size());
                    break;
                case 2:
                    List<Book> allBooks = bookService.getAllBooks();
                    allBooks.foreach(System.out::println);
                    break;
                case 3:
                    System.out.print("Ingrese el ID del libro: ");
                    Long id = scanner.nextLong();
                    bookService.getBookById(id).ifPresentOrElse(
                            System.out::println,
                            () -> System.out.println("Libro no encontrado"));
                    break;
                case 4:
                    System.out.print("Ingrese el ID del libro a eliminar: ");
                    Long deleteId = scanner.nextLong();
                    bookService.deleteBook(deleteId);
                    System.out.println("Libro eliminado");
                    break;
                case 5:
                    bookService.deleteAllBooks();
                    System.out.println("Todos los libros han sido eliminados");
                    break;
                case 6:
                    running = false;
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        }
    }
}
